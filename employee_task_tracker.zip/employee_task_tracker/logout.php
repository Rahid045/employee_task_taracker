<?php
session_start();
require_once __DIR__ . '/app/init.php';

destroyUserSession();

header('Location: login.php');
exit;
