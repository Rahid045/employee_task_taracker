<?php
session_start();
require_once __DIR__ . '/app/init.php';
requireLogin();

$user = $_SESSION['user'];
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');

        if (!$name || !$email) {
            $error = 'Name and email are required.';
        } else {
            try {
                $stmt = db()->prepare('UPDATE users SET name = :name, email = :email WHERE id = :id');
                $stmt->execute([
                    'name' => $name,
                    'email' => $email,
                    'id' => $user['id']
                ]);
                $_SESSION['user']['name'] = $name;
                $_SESSION['user']['email'] = $email;
                $user = $_SESSION['user'];
                $success = 'Profile updated successfully!';
            } catch (Exception $e) {
                $error = 'Failed to update profile: ' . $e->getMessage();
            }
        }
    } elseif ($action === 'change_password') {
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        if (!$current_password || !$new_password || !$confirm_password) {
            $error = 'All password fields are required.';
        } elseif ($new_password !== $confirm_password) {
            $error = 'New passwords do not match.';
        } elseif (strlen($new_password) < 6) {
            $error = 'New password must be at least 6 characters.';
        } else {
            try {
                $user_data = findUserByEmail($user['email']);
                if (!$user_data || !password_verify($current_password, $user_data['password'])) {
                    $error = 'Current password is incorrect.';
                } else {
                    $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
                    $stmt = db()->prepare('UPDATE users SET password = :password WHERE id = :id');
                    $stmt->execute([
                        'password' => $hashed_password,
                        'id' => $user['id']
                    ]);
                    $success = 'Password changed successfully!';
                }
            } catch (Exception $e) {
                $error = 'Failed to change password: ' . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile - Employee Task Tracker</title>
    <link rel="stylesheet" href="assets/styles.css">
    <style>
        .profile-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
        }

        @media (max-width: 900px) {
            .profile-container {
                grid-template-columns: 1fr;
            }
        }

        .profile-header {
            background: linear-gradient(135deg, #457b9d 0%, #2e5266 100%);
            color: white;
            padding: 2rem;
            border-radius: 12px;
            text-align: center;
            margin-bottom: 2rem;
        }

        .profile-avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            margin: 0 auto 1rem;
            border: 3px solid white;
        }

        .profile-header h2 {
            margin: 0;
            font-size: 1.8rem;
        }

        .profile-header p {
            margin: 0.5rem 0 0;
            opacity: 0.9;
        }

        .info-section {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(35, 47, 60, 0.08);
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
            border-bottom: 1px solid #f0f0f0;
        }

        .info-row:last-child {
            border-bottom: none;
        }

        .info-label {
            font-weight: 600;
            color: #333;
        }

        .info-value {
            color: #666;
        }

        .form-section {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(35, 47, 60, 0.08);
            margin-bottom: 1.5rem;
        }

        .form-section h3 {
            margin-top: 0;
            margin-bottom: 1.5rem;
            font-size: 1.2rem;
            color: #1d3557;
        }

        .form-actions {
            display: flex;
            gap: 1rem;
            margin-top: 1.5rem;
        }

        .activity-item {
            padding: 1rem 0;
            border-bottom: 1px solid #f0f0f0;
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-title {
            font-weight: 600;
            color: #333;
        }

        .activity-time {
            font-size: 0.85rem;
            color: #999;
            margin-top: 0.25rem;
        }
    </style>
</head>
<body>
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

    <header class="site-header">
        <div class="container">
            <h1>User Profile</h1>
        </div>
    </header>

    <main class="container">
        <?php if ($error): ?>
            <div class="alert error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <!-- Profile Header -->
        <div class="profile-header">
            <div class="profile-avatar"><?= strtoupper(substr($user['name'], 0, 1)) ?></div>
            <h2><?= htmlspecialchars($user['name']) ?></h2>
            <p><?= htmlspecialchars($user['email']) ?></p>
            <p style="font-size: 0.9rem; margin-top: 0.5rem;">Role: <strong><?= ucfirst($user['role']) ?></strong></p>
        </div>

        <div class="profile-container">
            <!-- Profile Information -->
            <div>
                <div class="form-section">
                    <h3>Profile Information</h3>
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="update_profile">

                        <label for="name">Full Name</label>
                        <input type="text" id="name" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>

                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>

                        <label for="role">Role</label>
                        <input type="text" id="role" value="<?= ucfirst($user['role']) ?>" disabled style="background: #f5f5f5; cursor: not-allowed;">

                        <div class="form-actions">
                            <button type="submit" class="button primary">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Account Settings -->
            <div>
                <div class="form-section">
                    <h3>Change Password</h3>
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="change_password">

                        <label for="current_password">Current Password</label>
                        <input type="password" id="current_password" name="current_password" required>

                        <label for="new_password">New Password</label>
                        <input type="password" id="new_password" name="new_password" required>

                        <label for="confirm_password">Confirm New Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" required>

                        <div class="form-actions">
                            <button type="submit" class="button primary">Update Password</button>
                        </div>
                    </form>
                </div>

                <!-- Account Information -->
                <div class="info-section">
                    <h3 style="margin-top: 0;">Account Information</h3>
                    <div class="info-row">
                        <span class="info-label">User ID</span>
                        <span class="info-value">#<?= htmlspecialchars($user['id']) ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Member Since</span>
                        <span class="info-value"><?= date('M d, Y') ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Status</span>
                        <span class="info-value" style="color: #2a9d8f;">Active</span>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="assets/app.js"></script>
</body>
</html>
