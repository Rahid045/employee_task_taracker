<?php
session_start();
require_once __DIR__ . '/app/init.php';
requireLogin();

$user = $_SESSION['user'];

// Only allow non-employees to delete
if ($user['role'] === 'employee') {
    die('Unauthorized');
}

if (isset($_GET['id'])) {
    $id = (int) $_GET['id'];

    try {
        $stmt = db()->prepare('DELETE FROM projects WHERE id = ?');
        $stmt->execute([$id]);
    } catch (Exception $e) {
        die('Error deleting project: ' . $e->getMessage());
    }
}

header('Location: project_task_management.php');
exit;

// Before deleting, get task + assignee
$stmt = $pdo->prepare("SELECT id, title, assigned_to FROM tasks WHERE id = ?");
$stmt->execute([$_POST['task_id']]);
$task = $stmt->fetch();

if ($task && $task['assigned_to']) {
    // Notify the user who owned it
    createNotification(
        $task['assigned_to'],
        'deleted',
        'Task Deleted',
        'Task "' . substr($task['title'], 0, 40) . '" was deleted.',
        '🗑️'
    );
}

// Now delete
$pdo->prepare("DELETE FROM tasks WHERE id = ?")->execute([$_POST['task_id']]);
