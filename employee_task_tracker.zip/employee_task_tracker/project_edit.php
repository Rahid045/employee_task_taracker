<?php
session_start();
require_once __DIR__ . '/app/init.php';
requireLogin();

$user = $_SESSION['user'];
if ($user['role'] === 'employee') {
    die('Unauthorized');
}

$id = (int) $_GET['id'];
$stmt = db()->prepare('SELECT * FROM projects WHERE id = ?');
$stmt->execute([$id]);
$project = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $status = $_POST['status'];

    $stmt = db()->prepare('UPDATE projects SET name=?, description=?, status=? WHERE id=?');
    $stmt->execute([$name, $description, $status, $id]);

    header('Location: project_task_management.php');
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Project</title>
</head>
<link rel="stylesheet" href="assets/styles.css">

<style>
    /* assets/styles.css */

/* Base */
* {
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
    background: #fffad1;
    color: #2d3748;
    margin: 0;
    padding: 40px;
    line-height: 1.5;
}

/* Page heading */
h1 {
    max-width: 640px;
    margin: 0 auto 25px;
    font-size: 28px;
    font-weight: 700;
    color: #1a202c;
}

/* Form card */
form {
    max-width: 640px;
    margin: 0 auto;
    background: #ffffff;
    padding: 32px;
    border-radius: 10px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
    display: flex;
    flex-direction: column;
    gap: 20px; /* space between label+input groups */
}

/* Labels */
form label {
    display: block;
    font-weight: 600;
    font-size: 14px;
    color: #4a5568;
    margin-bottom: 6px;
}

/* Inputs, textarea, select */
form input[type="text"],
form textarea,
form select {
    width: 100%;
    padding: 11px 14px;
    border: 1px solid #cbd5e0;
    border-radius: 6px;
    font-size: 15px;
    background: #fff;
    color: #2d3748;
    transition: border-color 0.2s, box-shadow 0.2s;
}

form textarea {
    min-height: 120px;
    resize: vertical;
    font-family: inherit;
}

/* Focus state */
form input[type="text"]:focus,
form textarea:focus,
form select:focus {
    border-color: #e30613;
    box-shadow: 0 0 0 3px rgba(43, 181, 167, 0.15);
    outline: none;
}

/* Button */
form button[type="submit"] {
    align-self: flex-start; /* don't stretch button full width */
    background: #e30613;
    color: white;
    border: none;
    padding: 12px 24px;
    border-radius: 6px;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    margin-top: 8px;
    transition: background 0.2s, transform 0.05s;
}

form button[type="submit"]:hover {
    background: #249e92;
}

form button[type="submit"]:active {
    transform: translateY(1px);
}

/* Mobile */
@media (max-width: 640px) {
    body {
        padding: 20px;
    }
    form {
        padding: 20px;
    }
    h1 {
        font-size: 24px;
    }
}
</style>
        
<body>
    <h1>Edit Project</h1>
    <form method="post">
        <label>Name</label>
        <input type="text" name="name" value="<?= htmlspecialchars($project['name']) ?>" required>
        
        <label>Description</label>
        <textarea name="description"><?= htmlspecialchars($project['description']) ?></textarea>
        
        <label>Status</label>
        <select name="status">
            <option value="active" <?= $project['status']=='active'?'selected':'' ?>>Active</option>
            <option value="on_hold" <?= $project['status']=='on_hold'?'selected':'' ?>>On Hold</option>
            <option value="completed" <?= $project['status']=='completed'?'selected':'' ?>>Completed</option>
        </select>
        
        <button type="submit">Save Changes</button>
    </form>
</body>
</html>
