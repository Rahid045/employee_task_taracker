<?php
session_start();
require_once __DIR__ . '/app/init.php';
requireLogin();

$user = $_SESSION['user'];

// Fetch projects

$projects = [];
try {
    $stmt = db()->prepare('SELECT * FROM project_task_management ORDER BY created_at ASC;');
    $stmt->execute();
    $projects = $stmt->fetchAll();
} catch (Exception $e) {
    // Projects table may not exist yet
}

// Fetch tasks for the user
$tasks = getTasksForUser($user);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projects & Tasks - Employee Task Tracker</title>
    <link rel="stylesheet" href="assets/styles.css">
    <style>
        .project-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .project-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 12px rgba(35, 47, 60, 0.08);
            border-left: 4px solid #457b9d;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .project-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 20px rgba(35, 47, 60, 0.12);
        }

        .project-card h3 {
            margin: 0 0 0.5rem;
            color: #1d3557;
            font-size: 1.2rem;
        }

        .project-card .description {
            color: #666;
            font-size: 0.9rem;
            margin-bottom: 1rem;
            line-height: 1.4;
        }

        .project-status {
            display: inline-block;
            padding: 0.35rem 0.65rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }

        .project-status.active { background: #e6f7e6; color: #2a7a2a; }
        .project-status.on_hold { background: #fff3cd; color: #7f6d0a; }
        .project-status.completed { background: #e6f0ff; color: #0051ba; }

        .project-actions {
            display: flex;
            gap: 0.5rem;
            margin-top: 1rem;
        }

        .project-actions a {
            flex: 1;
        }

        .stats-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: linear-gradient(135deg, #457b9d 0%, #2e5266 100%);
            color: white;
            padding: 1.5rem;
            border-radius: 12px;
            text-align: center;
        }

        .stat-card h4 {
            margin: 0 0 0.5rem;
            font-size: 0.9rem;
            opacity: 0.9;
        }

        .stat-card .value {
            font-size: 2rem;
            font-weight: 700;
        }
    </style>
</head>
<body>
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

    <header class="site-header">
        <div class="container">
             <img src="images/logo.png" alt="logo" class="login-logo">
            <h1>Projects & Tasks Management</h1>
        </div>
    </header>

    <main class="container">
        <!-- Statistics -->
        <section class="stats-row">
            <div class="stat-card">
                <h4>Total Projects</h4>
                <div class="value"><?= count($projects) ?></div>
            </div>
            <div class="stat-card">
                <h4>Active Tasks</h4>
                <div class="value"><?= count(array_filter($tasks, fn($t) => $t['status'] !== 'completed')) ?></div>
            </div>
            <div class="stat-card">
                <h4>Completed Tasks</h4>
                <div class="value"><?= count(array_filter($tasks, fn($t) => $t['status'] === 'completed')) ?></div>
            </div>
        </section>

        <!-- Projects Section -->
         
        <section class="panel">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                <h2>Projects</h2>
                <?php if ($user['role'] !== 'employee'): ?>
                    <a href="project_create.php" class="button primary">+ New Project</a>
                <?php endif; ?>
            </div>

            <?php if (empty($projects)): ?>
                <p style="text-align: center; color: #999; padding: 2rem;">No projects yet.</p>
            <?php else: ?>
                <div class="project-grid">
                    <?php foreach ($projects as $project): ?>
                        <div class="project-card">
                            <h3><?= htmlspecialchars($project['name']) ?></h3>
                            <span class="project-status <?= $project['status'] ?>"><?= ucwords(str_replace('_', ' ', $project['status'])) ?></span>
                            <p class="description"><?= htmlspecialchars($project['description'] ?? 'No description') ?></p>
                            <small style="color: #999;">Created <?= date('M d, Y', strtotime($project['created_at'])) ?></small>
                        </div>

                    <div class="project-card">
    <h3><?= htmlspecialchars($project['name']) ?></h3>
    <span class="project-status <?= $project['status'] ?>">
        <?= ucwords(str_replace('_', ' ', $project['status'])) ?>
    </span>
    <p class="description"><?= htmlspecialchars($project['description'] ?? 'No description') ?></p>
    <small style="color: #999;">Created <?= date('M d, Y', strtotime($project['created_at'])) ?></small>

    <div class="project-actions">
        <a href="project_edit.php?id=<?= $project['id'] ?>" class="button small">Edit</a>
        <a href="project_delete.php?id=<?= $project['id'] ?>" 
           class="button small danger"
           onclick="return confirm('Are you sure you want to delete this project?');">
           Delete
        </a>
    </div>
</div>


                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <!-- Tasks Section -->
        <section class="panel">
            <h2 style="margin-top: 0;">Recent Tasks</h2>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Assigned To</th>
                            <th>Status</th>
                            <th>Priority</th>
                            <th>Due Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (array_slice($tasks, 0, 10) as $task): ?>
                            <tr>
                                <td><?= htmlspecialchars(substr($task['title'], 0, 30)) ?></td>
                                <td><?= htmlspecialchars($task['assigned_to_name'] ?? 'Unassigned') ?></td>
                                <td><span class="status <?= $task['status'] ?>"><?= ucfirst(str_replace('_', ' ', $task['status'])) ?></span></td>
                                <td><?= ucfirst($task['priority']) ?></td>
                                <td><?= $task['due_date'] ?: '-' ?></td>
                                <td>
                                    <a class="button small" href="task_view.php?id=<?= $task['id'] ?>">View</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($tasks)): ?>
                            <tr><td colspan="6" style="text-align: center;">No tasks found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>

    <script src="assets/app.js"></script>
</body>
</html>
